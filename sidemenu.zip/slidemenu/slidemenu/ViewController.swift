
import UIKit
class sidemenulist {
    var itemname: String?
    var itemicon: String?

    init(itName:String, iticon:String) {
        self.itemname = itName
        self.itemicon = iticon
    }
}
class ViewController: UIViewController {
    
    var itemArray = [sidemenulist]()
    let height = UIScreen.main.bounds.size.height
    let width = (UIScreen.main.bounds.size.width)*3/4
    var transparentView = UIView()
    var tableView = UITableView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let cpwd = sidemenulist(itName: "Change Password", iticon: "Change Password")
        itemArray.append(cpwd)
        let fav = sidemenulist(itName: "Favorite", iticon: "Favorite")
        itemArray.append(fav)
        let noti = sidemenulist(itName: "Notification", iticon: "Notification")
        itemArray.append(noti)
        let logout = sidemenulist(itName: "Logout", iticon: "Logout")
        itemArray.append(logout)
        tableView.isScrollEnabled = true
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(CustomTableViewCell.self, forCellReuseIdentifier: "Cell")
        // Do any additional setup after loading the view.
    }
    
    @IBAction func menuBtn(_ sender: UIBarButtonItem) {
        let window=UIApplication.shared.keyWindow
        transparentView.backgroundColor=UIColor.black.withAlphaComponent(0.8)
        transparentView.frame=self.view.frame
        window?.addSubview(transparentView)

        let screenSize = UIScreen.main.bounds.size
        tableView.frame=CGRect(x: -(screenSize.width), y: 0, width: width, height: screenSize.height)
        window?.addSubview(tableView)

        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(onClickTransparentView))
        transparentView.addGestureRecognizer(tapGesture)
        transparentView.alpha = 0
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: .curveEaseIn, animations: {
            self.transparentView.alpha=0.1
            self.tableView.frame = CGRect(x: 0, y: 0, width:self.width, height: screenSize.height)
        }, completion: nil)
    }
    
    @objc func onClickTransparentView(){

        let screenSize = UIScreen.main.bounds.size
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: .curveEaseIn, animations: {
            self.transparentView.alpha=0
            self.tableView.frame = CGRect(x: -(screenSize.width), y: 0, width:self.width, height: screenSize.height)
        }, completion: nil)
    }
}

extension ViewController:UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)as?
                CustomTableViewCell else {fatalError("Unable to run")}
        cell.lbl.text = itemArray[indexPath.row].itemname
        
        cell.imageView?.image=UIImage(named: itemArray[indexPath.row].itemicon!)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            performSegue(withIdentifier: "showdetail", sender: self)
        }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if let destination = segue.destination as? FirstViewController {
                let screenSize = UIScreen.main.bounds.size
                UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: .curveEaseIn, animations: {
                    self.transparentView.alpha=0
                    self.tableView.frame = CGRect(x: -(screenSize.width), y: 0, width:self.width, height: screenSize.height)
                }, completion: nil)
                destination.detailsproduct = itemArray[(tableView.indexPathForSelectedRow?.row)!]
                tableView.deselectRow(at: tableView.indexPathForSelectedRow!, animated: true)

            }
        }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
}
