//
//  FirstViewController.swift
//  slidemenu
//
//  Created by Anilkumar on 01/06/22.
//

import UIKit
class firstmenulist {
    var itemname: String?
    var itemicon: String?

    init(itName:String, iticon:String) {
        self.itemname = itName
        self.itemicon = iticon
    }
}
class FirstViewController: UIViewController {
    
    
    let height = UIScreen.main.bounds.size.height
    let width = (UIScreen.main.bounds.size.width)*3/4
    var transparentView = UIView()
    var tableView = UITableView()
    var firstitemArray = [firstmenulist]()
    
    
    
    
    @IBAction func menubtn(_ sender: UIButton) {
        execute()
        
        let window=UIApplication.shared.keyWindow
        transparentView.backgroundColor=UIColor.black.withAlphaComponent(0.8)
        transparentView.frame=self.view.frame
        window?.addSubview(transparentView)

        let screenSize = UIScreen.main.bounds.size
        tableView.frame=CGRect(x: -(screenSize.width), y: 0, width: width, height: screenSize.height)
        window?.addSubview(tableView)

        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(onClickTransparentView))
        transparentView.addGestureRecognizer(tapGesture)
        transparentView.alpha = 0
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: .curveEaseIn, animations: {
            self.transparentView.alpha=0.1
            self.tableView.frame = CGRect(x: 0, y: 0, width:self.width, height: screenSize.height)
        }, completion: nil)
    }
    
    
    @objc func onClickTransparentView(){

        let screenSize = UIScreen.main.bounds.size
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: .curveEaseIn, animations: {
            self.transparentView.alpha=0
            self.tableView.frame = CGRect(x: -(screenSize.width), y: 0, width:self.width, height: screenSize.height)
        }, completion: nil)
    }
    
    
    @IBOutlet weak var detaillbl: UILabel!
    var detailsproduct: sidemenulist?
    func execute()
    {
        let cpwd = firstmenulist(itName: "Change Password", iticon: "Change Password")
        firstitemArray.append(cpwd)
        let fav = firstmenulist(itName: "Favorite", iticon: "Favorite")
        firstitemArray.append(fav)
        let noti = firstmenulist(itName: "Notification", iticon: "Notification")
        firstitemArray.append(noti)
        let logout = firstmenulist(itName: "Logout", iticon: "Logout")
        firstitemArray.append(logout)
        tableView.isScrollEnabled = true
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(CustomTableViewCell.self, forCellReuseIdentifier: "Cell")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        detaillbl.text = "\((detailsproduct?.itemname)!) comes along with the icon \((detailsproduct?.itemicon)!)"
        if((detailsproduct?.itemname) == "Change Password")
        {
            self.view.backgroundColor = UIColor.cyan
        }
        else if((detailsproduct?.itemname) == "Notification")
        {
            self.view.backgroundColor = UIColor.red
        }
        else if((detailsproduct?.itemname) == "Logout")
        {
            self.view.backgroundColor = UIColor.lightGray
        }
        else if((detailsproduct?.itemname) == "Favorite")
        {
            self.view.backgroundColor = UIColor.magenta
        }
        
    }
    

    

}
extension FirstViewController:UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return firstitemArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)as?
                CustomTableViewCell else {fatalError("Unable to run")}
        cell.lbl.text = firstitemArray[indexPath.row].itemname
        
        cell.imageView?.image=UIImage(named: firstitemArray[indexPath.row].itemicon!)
        return cell
    }
    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//
//        detailsproduct = firstitemArray[tableView.indexPathForSelectedRow!]
//                tableView.deselectRow(at: tableView.indexPathForSelectedRow!, animated: true)
//
//            }
//    }
        
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
}


