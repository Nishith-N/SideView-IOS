//
//  HomeViewController.swift
//  reference_sidemenu
//
//  Created by Anilkumar on 03/06/22.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var homeitem: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()
        homeitem.target = revealViewController()
        homeitem.action = #selector(revealViewController()?.revealSideMenu)
        self.view.backgroundColor = .red

        // Do any additional setup after loading the view.
    }
    

  

}
