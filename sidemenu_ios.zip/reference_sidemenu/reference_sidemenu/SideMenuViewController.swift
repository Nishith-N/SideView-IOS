//
//  SideMenuViewController.swift
//  reference_sidemenu
//
//  Created by Anilkumar on 02/06/22.
//

import UIKit
protocol SideMenuViewControllerDelegate{
    func selectedCell(_row: Int)
}
class sidemenulist {
    var itemname: String?
    var itemicon: String?

    init(itName:String, iticon:String) {
        self.itemname = itName
        self.itemicon = iticon
    }
}

class SideMenuViewController: UIViewController {
   
    var delegate: SideMenuViewControllerDelegate?
    
    var itemArray = [sidemenulist]()
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let cpwd = sidemenulist(itName: "Change Password", iticon: "Change Password")
        itemArray.append(cpwd)
//        let fav = sidemenulist(itName: "Favorite", iticon: "Favorite")
//        itemArray.append(fav)
//        let noti = sidemenulist(itName: "Notification", iticon: "Notification")
//        itemArray.append(noti)
        let logout = sidemenulist(itName: "Logout", iticon: "Logout")
        itemArray.append(logout)
        tableView.register(SideMenuCell.self, forCellReuseIdentifier: "Cell")
        self.tableView.delegate = self
                self.tableView.dataSource = self
        self.tableView.backgroundColor = .green
                self.tableView.separatorStyle = .none
        self.tableView.reloadData()
       

        // Do any additional setup after loading the view.
    }
    

    /*
     import UIKit

     class CustomTableViewCell: UITableViewCell {
         lazy var backView: UIView = {
             let view = UIView(frame: CGRect(x: 0, y: 0, width: self.frame.width, height: 50))
             return view
         }()
         lazy var settingImage: UIImageView = {
             let imageView = UIImageView(frame: CGRect(x: 15, y: 10, width: 30, height: 30))
             imageView.contentMode = .scaleAspectFit
             return imageView
         }()
         lazy var lbl: UILabel = {
             let btn = UILabel(frame: CGRect(x: 60, y: 10, width: self.frame.width-80, height: 30))
         
             return btn
         }()
         override func awakeFromNib() {
             super.awakeFromNib()
             // Initialization code
         }

         override func setSelected(_ selected: Bool, animated: Bool) {
             super.setSelected(selected, animated: animated)
             addSubview(backView)
             backView.addSubview(settingImage)
             backView.addSubview(lbl)
          
         }

     }

    */

}
extension SideMenuViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
}

extension SideMenuViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as? SideMenuCell else { fatalError("xib doesn't exist")}
        cell.lbl.text = self.itemArray[indexPath.row].itemname
        cell.lbl.textColor = .cyan
        cell.backgroundColor = .white
        cell.imageView?.image=UIImage(named: itemArray[indexPath.row].itemicon!)
        

                // Highlighted color
                let myCustomSelectionColorView = UIView()
        myCustomSelectionColorView.backgroundColor = UIColor.red
                                                    
                cell.selectedBackgroundView = myCustomSelectionColorView
                return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
            self.delegate?.selectedCell(_row: indexPath.row)
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.itemArray.count
    }
}
