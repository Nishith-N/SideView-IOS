//
//  MainViewController.swift
//  reference_sidemenu
//
//  Created by Anilkumar on 02/06/22.
//

import UIKit


class MainViewController: UIViewController {

    
    @IBAction open func revealSideMenu() {
        self.sideMenuState(expanded: self.isExpanded ? false : true)
    }
 

    
    private var sideMenuViewController: SideMenuViewController!
        private var sideMenuRevealWidth: CGFloat = 260
    private var revealSideMenuOnTop: Bool = true
    private var draggingIsEnabled: Bool = false
        private var panBaseLocation: CGFloat = 0.0
    private var isExpanded: Bool = false
    private var sideMenuTrailingConstraint: NSLayoutConstraint!
    private let paddingForRotation: CGFloat = 150

    override func viewDidLoad() {
        super.viewDidLoad()
        let panGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(handlePanGesture))
                panGestureRecognizer.delegate = self
                view.addGestureRecognizer(panGestureRecognizer)
        self.view.backgroundColor = .brown
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        //to be asked
                self.sideMenuViewController = storyboard.instantiateViewController(withIdentifier: "SideMenuID") as? SideMenuViewController
        self.sideMenuViewController.delegate = self
                view.insertSubview(self.sideMenuViewController!.view, at: self.revealSideMenuOnTop ? 2 : 0)
                addChild(self.sideMenuViewController!)
                self.sideMenuViewController!.didMove(toParent: self)
        self.sideMenuViewController.view.translatesAutoresizingMaskIntoConstraints = false

                if self.revealSideMenuOnTop {
                    self.sideMenuTrailingConstraint = self.sideMenuViewController.view.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: -self.sideMenuRevealWidth - self.paddingForRotation)
                    self.sideMenuTrailingConstraint.isActive = true
                }
                NSLayoutConstraint.activate([
                    self.sideMenuViewController.view.widthAnchor.constraint(equalToConstant: self.sideMenuRevealWidth),
                    self.sideMenuViewController.view.bottomAnchor.constraint(equalTo: view.bottomAnchor),
                    self.sideMenuViewController.view.topAnchor.constraint(equalTo: view.topAnchor)
                ])
   
    
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
}
extension MainViewController: SideMenuViewControllerDelegate {

    func selectedCell(_row row : Int) {
           switch row {
                   
             
                   case 0:
                       
               let vc = ChangeViewController()
      navigationController?.pushViewController(vc, animated: true)
                   case 1:
                      
               let vc = logoutViewController()
               navigationController?.pushViewController(vc, animated: true)
                    default:
                       break
           }
        DispatchQueue.main.async { self.sideMenuState(expanded: false) }
    }
    
    func showViewController<T: UIViewController>(viewController: T.Type, storyboardId: String) -> () {
            // Remove the previous View
            for subview in view.subviews {
                if subview.tag == 99 {
                    subview.removeFromSuperview()
                }
            }
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: storyboardId) as! T
            vc.view.tag = 99
            view.insertSubview(vc.view, at: self.revealSideMenuOnTop ? 0 : 1)
            addChild(vc)
            vc.view.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                vc.view.leadingAnchor.constraint(equalTo: self.view.leadingAnchor),
                vc.view.topAnchor.constraint(equalTo: self.view.topAnchor),
                vc.view.bottomAnchor.constraint(equalTo: self.view.bottomAnchor),
                vc.view.trailingAnchor.constraint(equalTo: self.view.trailingAnchor)
            ])
            if !self.revealSideMenuOnTop {
                if isExpanded {
                    vc.view.frame.origin.x = self.sideMenuRevealWidth
                }
               
            }
            vc.didMove(toParent: self)
        }

        func sideMenuState(expanded: Bool) {
            if expanded {
                self.animateSideMenu(targetPosition: self.revealSideMenuOnTop ? 0 : self.sideMenuRevealWidth) { _ in
                    self.isExpanded = true
                }
                // Animate Shadow (Fade In)
              
            }
            else {
                self.animateSideMenu(targetPosition: self.revealSideMenuOnTop ? (-self.sideMenuRevealWidth - self.paddingForRotation) : 0) { _ in
                    self.isExpanded = false
                }
                // Animate Shadow (Fade Out)
                
            }
        }
    func animateSideMenu(targetPosition: CGFloat, completion: @escaping (Bool) -> ()) {
           UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1.0, initialSpringVelocity: 0, options: .layoutSubviews, animations: {
               if self.revealSideMenuOnTop {
                   self.sideMenuTrailingConstraint.constant = targetPosition
                   self.view.layoutIfNeeded()
               }
               else {
                   self.view.subviews[1].frame.origin.x = targetPosition
               }
           }, completion: completion)
       }
}

extension UIViewController {
    
    // With this extension you can access the MainViewController from the child view controllers.
    func revealViewController() -> MainViewController? {
        var viewController: UIViewController? = self
        
        if viewController != nil && viewController is MainViewController {
            return viewController! as? MainViewController
        }
        while (!(viewController is MainViewController) && viewController?.parent != nil) {
            viewController = viewController?.parent
        }
        if viewController is MainViewController {
            return viewController as? MainViewController
        }
        return nil
    }
    

    
    
}

extension MainViewController: UIGestureRecognizerDelegate {
    
    // Dragging Side Menu
    @objc private func handlePanGesture(sender: UIPanGestureRecognizer) {
        
        // ...

        let position: CGFloat = sender.translation(in: self.view).x
        let velocity: CGFloat = sender.velocity(in: self.view).x

        switch sender.state {
        case .began:

            // If the user tries to expand the menu more than the reveal width, then cancel the pan gesture
            if velocity > 0, self.isExpanded {
                sender.state = .cancelled
            }

            // If the user swipes right but the side menu hasn't expanded yet, enable dragging
            if velocity > 0, !self.isExpanded {
                self.draggingIsEnabled = true
            }
            // If user swipes left and the side menu is already expanded, enable dragging they collapsing the side menu)
            else if velocity < 0, self.isExpanded {
                self.draggingIsEnabled = true
            }

            if self.draggingIsEnabled {
                // If swipe is fast, Expand/Collapse the side menu with animation instead of dragging
                let velocityThreshold: CGFloat = 550
                if abs(velocity) > velocityThreshold {
                    self.sideMenuState(expanded: self.isExpanded ? false : true)
                    self.draggingIsEnabled = false
                    return
                }

                if self.revealSideMenuOnTop {
                    self.panBaseLocation = 0.0
                    if self.isExpanded {
                        self.panBaseLocation = self.sideMenuRevealWidth
                    }
                }
            }

        case .changed:

            // Expand/Collapse side menu while dragging
            if self.draggingIsEnabled {
                if self.revealSideMenuOnTop {
                    // Show/Hide shadow background view while dragging
                                     

                    
                    

                    // Move side menu while dragging
//                    if xLocation <= self.sideMenuRevealWidth {
//                        self.sideMenuTrailingConstraint.constant = xLocation - self.sideMenuRevealWidth
//                    }
                }
               
            }
        case .ended:
            self.draggingIsEnabled = false
            // If the side menu is half Open/Close, then Expand/Collapse with animationse with animation
            if self.revealSideMenuOnTop {
                let movedMoreThanHalf = self.sideMenuTrailingConstraint.constant > -(self.sideMenuRevealWidth * 0.5)
                self.sideMenuState(expanded: movedMoreThanHalf)
            }
            else {
                if let recogView = sender.view?.subviews[1] {
                    let movedMoreThanHalf = recogView.frame.origin.x > self.sideMenuRevealWidth * 0.5
                    self.sideMenuState(expanded: movedMoreThanHalf)
                }
            }
        default:
            break
        }
    }
}


