//
//  SideMenuCell.swift
//  reference_sidemenu
//
//  Created by Anilkumar on 02/06/22.
//

import UIKit

class SideMenuCell: UITableViewCell {

    lazy var settingImage: UIImageView = {
        let imageView = UIImageView(frame: CGRect(x: 15, y: 10, width: 30, height: 30))
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    lazy var lbl: UILabel = {
        let btn = UILabel(frame: CGRect(x: 60, y: 10, width: self.frame.width-80, height: 30))
    
        return btn
    }()
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
